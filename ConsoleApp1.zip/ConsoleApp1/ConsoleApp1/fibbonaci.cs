﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //HARD CODED EXAMPLES OF 15 AND 22 PER HW1 MODULE INSTRUCTTION/SUGGESTION
            int ans1 = Fibbonaci(15);
            int ans2 = Fibbonaci(22);
            

            //PRINT ANSWER OF 15TH AND 22ND NUMBER IN FIBBONACI SEQUENCE 
            //FOLLOWED BY THE FIRST 22 NUMBERS OF THE SEQUENCE
            Console.WriteLine("Fibbonaci(15) = {0}", ans1);
            Console.WriteLine("Fibbonaci(22) = {0}", ans2);
            Console.Write(FibbonaciNums(22));


        }

        //FUNCTION TO GET FIBBONACI NUMBER REQUESTED IN ARGUMENT
        static int Fibbonaci(int N)
        {
            int val1 = 0;
            int val2 = 1;
            int sum = 0;

            for (int i = 2; i <= N; i++)
            {
                sum = val1 + val2;
                val1 = val2;
                val2 = sum;
            }
            return sum;
        }

        //FUNCTION TO PRINT OUT FIRST 22 NUMBERS IN SEQUENCE
        static int FibbonaciNums(int a)
        {
            int val1 = 0;
            int val2 = 1;
            int sum = 0;
            Console.WriteLine("fib(0) = {0}", val1);
            Console.WriteLine("fib(1) = {0}", val2);
            for (int i = 2; i <= a; i++)
            {
                sum = val1 + val2;
                Console.WriteLine("fib({0}) = {1}", i, sum);
                val1 = val2;
                val2 = sum;
            }
            return 0;
        }
            

            
    }
}

